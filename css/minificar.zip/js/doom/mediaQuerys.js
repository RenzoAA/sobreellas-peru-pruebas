const d = document;
export default function mediaQuerys(img1, img2, img3) {
  const $imgSlider1 = d.querySelector(img1),
    $imgSlider2 = d.querySelector(img2),
    $imgSlider3 = d.querySelector(img3);
    
    addEventListener('resize', () => {
      if (innerWidth > 767) {
        $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-desktop.jpg")
        $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-desktop.jpg")
        $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-desktop.jpg")
      }else if(innerWidth < 768){
        $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-mobile.jpg")
        $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-mobile.jpg")
        $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-mobile.jpg")
      }else if(innerWidth > 1199){
        $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-desktop.jpg")
        $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-desktop.jpg")
        $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-desktop.jpg")
      }else if(innerWidth < 1200){
        $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-tablet.jpg")
        $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-tablet.jpg")
        $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-tablet.jpg")
      }
  })

  addEventListener("DOMContentLoaded",()=>{
    if (innerWidth > 767) {
      $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-desktop.jpg")
        $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-desktop.jpg")
        $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-desktop.jpg")
    }else if(innerWidth < 768){
      $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-mobile.jpg")
      $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-mobile.jpg")
      $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-mobile.jpg")
    }else if(innerWidth > 1199){
      $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-desktop.jpg")
      $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-desktop.jpg")
      $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-desktop.jpg")
    }else if(innerWidth < 1200){
      $imgSlider1.setAttribute("src", "imagenes/slider-inicio/slider-1-tablet.jpg")
      $imgSlider2.setAttribute("src", "imagenes/slider-inicio/slider-2-tablet.jpg")
      $imgSlider3.setAttribute("src", "imagenes/slider-inicio/slider-3-tablet.jpg")
    }
  })
}
